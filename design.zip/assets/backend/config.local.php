<?php
declare(strict_types=1);

return array (
  'environment' => 'auto',
  'base_url' => 
  array (
    'local' => 'http://localhost/Kumo',
    'production' => 'https://kumo.ct.ws',
  ),
  'database' => 
  array (
    'local' => 
    array (
      'host' => '127.0.0.1',
      'username' => 'root',
      'password' => '',
      'name' => 'users',
    ),
    'production' => 
    array (
      'host' => 'sql303.infinityfree.com',
      'username' => 'if0_43136431',
      'password' => 'LJfLZjDnMpk2I1',
      'name' => 'if0_43136431_users',
    ),
  ),
  'google' => 
  array (
    'client_id' => '823798641041-b3dok67iorn2ond0tsf3hvsvp9786m08.apps.googleusercontent.com',
    'client_secret' => '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',
    'redirect_uri' => 'https://kumo.ct.ws/assets/backend/google_callback.php',
  ),
  'mail_from' => 'cloudmail.kumo@gmail.com',
  'smtp' => 
  array (
    'host' => 'smtp.gmail.com',
    'port' => 587,
    'username' => 'cloudmail.kumo@gmail.com',
    'password' => 'lqld prbh rtnx vzfm',
    'encryption' => 'tls',
  ),
);
