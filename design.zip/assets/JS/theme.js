(function () {
  'use strict';
  const root = document.documentElement;
  let preferences = {};
  try { preferences = JSON.parse(localStorage.getItem('kumoPreferences') || '{}'); } catch (_) {}
  const systemDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)');
  // Missing / invalid preference resolves to light — never OS dark by default.
  const normalizeTheme = (value) => ['light', 'dark', 'system'].includes(value) ? value : 'light';
  function apply() {
    const raw = preferences.theme || localStorage.getItem('kumoTheme') || 'light';
    const theme = normalizeTheme(raw);
    root.dataset.themePreference = theme;
    root.dataset.theme = theme === 'system' ? ((systemDark && systemDark.matches) ? 'dark' : 'light') : theme;
    root.dataset.accent = ['sage', 'forest', 'ocean', 'lavender'].includes(preferences.accent_color) ? preferences.accent_color : 'sage';
    root.dataset.density = ['comfortable', 'compact'].includes(preferences.density) ? preferences.density : 'comfortable';
    root.classList.toggle('reduce-motion', preferences.reduce_motion === true || preferences.reduce_motion === 1 || preferences.reduce_motion === '1');
  }
  apply();
  if (systemDark && typeof systemDark.addEventListener === 'function') {
    systemDark.addEventListener('change', () => {
      if (normalizeTheme(preferences.theme || localStorage.getItem('kumoTheme') || 'light') === 'system') apply();
    });
  }
})();
