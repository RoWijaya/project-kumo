(function () {
  "use strict";

  const gsap = window.gsap;
  if (!gsap) return;

  const media = gsap.matchMedia();
  media.add("(prefers-reduced-motion: no-preference)", () => {
    if (document.documentElement.classList.contains("reduce-motion")) return;

    const visible = (selector, root = document) => Array.from(root.querySelectorAll(selector))
      .filter((element) => !element.closest("[hidden]") && element.getClientRects().length > 0);
    const entrance = (elements, vars = {}) => {
      if (!elements.length) return;
      gsap.fromTo(elements, { autoAlpha: 0, y: 12 }, {
        autoAlpha: 1,
        y: 0,
        duration: 0.48,
        ease: "power2.out",
        stagger: 0.055,
        clearProps: "opacity,visibility,transform",
        ...vars,
      });
    };

    const landing = document.querySelector(".hero-section");
    if (landing) {
      const timeline = gsap.timeline({ defaults: { duration: 0.52, ease: "power2.out" } });
      timeline.fromTo(".site-nav", { autoAlpha: 0, y: -8 }, { autoAlpha: 1, y: 0, clearProps: "opacity,visibility,transform" });
      timeline.fromTo(visible(".hero-copy > *"), { autoAlpha: 0, y: 12 }, {
        autoAlpha: 1, y: 0, stagger: 0.06, clearProps: "opacity,visibility,transform",
      }, "<0.12");
      timeline.fromTo(".product-preview", { autoAlpha: 0, y: 14, scale: 0.99 }, {
        autoAlpha: 1, y: 0, scale: 1, duration: 0.68, clearProps: "opacity,visibility,transform",
      }, "<0.08");

      const rows = visible(".feature-row");
      if (rows.length && "IntersectionObserver" in window) {
        const observer = new IntersectionObserver((entries) => {
          const entering = entries.filter((entry) => entry.isIntersecting);
          if (!entering.length) return;
          entering.forEach((entry) => observer.unobserve(entry.target));
          entrance(entering.map((entry) => entry.target), { duration: 0.42, stagger: 0.06 });
        }, { threshold: 0.12 });
        rows.forEach((row) => observer.observe(row));
        return () => { timeline.kill(); observer.disconnect(); };
      }
      return () => timeline.kill();
    }

    const dashboard = document.querySelector(".main.dashboard-home");
    if (dashboard) {
      const timeline = gsap.timeline({ defaults: { duration: 0.45, ease: "power2.out" } });
      timeline.fromTo(visible(".search, .welcome, .dashboard-stats", dashboard),
        { autoAlpha: 0, y: 10 }, { autoAlpha: 1, y: 0, stagger: 0.045, clearProps: "opacity,visibility,transform" });
      timeline.fromTo(visible(".clouds-section, .overview-card, .task-overview", dashboard),
        { autoAlpha: 0, y: 12 }, { autoAlpha: 1, y: 0, stagger: 0.055, clearProps: "opacity,visibility,transform" }, "<0.12");
      entrance(visible(".cloud-card-link", dashboard), { duration: 0.38, stagger: 0.035 });
      return () => timeline.kill();
    }

    const authCard = document.querySelector(".auth-card");
    if (authCard) {
      entrance([authCard], { duration: 0.38, y: 8 });
      return;
    }

    const content = document.querySelector(".content, .editor-container");
    if (content) entrance([content], { duration: 0.42, y: 10 });
  });
})();
